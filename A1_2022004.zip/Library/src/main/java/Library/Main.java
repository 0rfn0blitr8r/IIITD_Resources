package Library;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		ArrayList<Book> bookList = new ArrayList<>();
		ArrayList<Member> memberList = new ArrayList<>();

		System.out.println("Library Portal Initialized....");
		while (true) {
			System.out.println("---------------------------------");
			System.out.println("1. Enter as a librarian\n2. Enter as a member\n3. Exit");
			System.out.println("---------------------------------");
			String input0 = scan.nextLine();

			//exit case
			if (input0.equals("3")) {
				break;
			}

			//librarian entry case
			else if (input0.equals("1")) {
				while (true) {
					System.out.println("---------------------------------");
					System.out.println("1. Register a member\n" +
										"2. Remove a member\n" +
										"3. Add a book\n" +
										"4. Remove a book\n" +
										"5. View all members along with their books and fines to be paid\n" +
										"6. View all books\n" +
										"7. Back");
					System.out.println("---------------------------------");
					String input1 = scan.nextLine();
					//scan.nextLine();

					//exit case
					if (input1.equals("7")) {
						System.out.println("Going back");
						System.out.println("---------------------------------");
						break;
					}

					//registering a member
					else if (input1.equals("1")) {
						System.out.println("---------------------------------");

						System.out.print("Enter new member's name: ");
						//scan.nextLine();
						String newMemName = scan.nextLine();

						System.out.print("Enter new member's phone number: ");
						String newMemPhNo = scan.nextLine();

						System.out.print("Enter new member's Age: ");
						int newMemAge = Integer.parseInt(scan.nextLine());
						//int newMemAge = scan.nextInt();

						String newMemId = newMemName + newMemPhNo;

						boolean memAlreadyExists = false;
						for(Member mem: memberList){
							if(mem.memId.equalsIgnoreCase(newMemId)){
								System.out.println("Member already exists");
								memAlreadyExists = true;
								break;
							}
						}

						//member already doesn't exist
						if(!memAlreadyExists){
							Member newMem = new Member(newMemName, newMemPhNo, newMemId, newMemAge);
							memberList.add(newMem);

							System.out.println("Successfully registered a new member with MemberID: " + newMemId);
						}
					}

					//remove a member
					else if (input1.equals("2")) {
						System.out.println("---------------------------------");
						System.out.println("Enter memberID to remove the unique member");
						//scan.nextLine();
						String memContact = scan.nextLine();

						boolean memExists = false;
						//removes all the members with matching entry; can use break statement to prevent that
						for (Member mem : memberList) {
							if (memContact.equalsIgnoreCase(mem.memId)) {
								memExists = true;
								//System.out.println("Member found!");
								long outstandingFine = mem.computeFine();
								if (outstandingFine > 0 || mem.memNumOfBooks != 0) {
									System.out.println("Clear all dues before removing");
								} else {
									memberList.remove(mem);
									System.out.println("Successfully removed member with memberID: " + memContact);
								}
								break;
							}
						}

						if(!memExists){
							System.out.println("No member with the provided contact doesn't exists.");
						}

					}

					//add a book
					else if (input1.equals("3")) {
						System.out.println("---------------------------------");
						//scan.nextLine();
						System.out.println("Enter Title of book: ");
						//scan.nextLine();
						String newBookTitle = scan.nextLine();

						System.out.println("Enter author of the book: ");
						//scan.nextLine();
						String newBookAuthor = scan.nextLine();

						System.out.println("Enter total copies of book: ");
						int newBookTotCopies = Integer.parseInt(scan.nextLine());

						String newBookId = newBookTitle + "_" + newBookAuthor;

						//if book already exists
						boolean bookExists = false;
						for(Book book : bookList){
							if(book.bookId.equalsIgnoreCase((newBookId)) && book.bookAuthor.equalsIgnoreCase(newBookAuthor) && book.bookTitle.equalsIgnoreCase(newBookTitle)){
								book.bookTotCopies += newBookTotCopies;
								System.out.println("Book already exists\nadded copies of the book");
								bookExists = true;
								break;
							}
						}

						if(!bookExists){
							Book newBook = new Book(newBookId, newBookTitle, newBookAuthor, newBookTotCopies);
							bookList.add(newBook);
							System.out.println("Book with ID " + newBookId + " has been successfully added");
						}
					}

					//Removing a book; reduce its total copies
					//through the for loop, reducing total-copies of all the books matching the entry by 1
					else if (input1.equals("4")) {
						System.out.println("---------------------------------");
						System.out.println("Enter bookID");
						//scan.nextLine();
						String bookContact = scan.nextLine();
						for (Book book : bookList) {
							if (bookContact.equalsIgnoreCase(book.bookId)) {
								//System.out.println("Book found!");
								if(book.bookTotCopies == 0){
									System.out.println("No copy to remove");
								}
								else {
									book.bookTotCopies = book.bookTotCopies - 1;
									System.out.println("Successfully removed a copy of the book");
								}
							}
						}
					}

					//memList with fines and books
					else if (input1.equals("5")) {
						System.out.println("---------------------------------");
						for (Member mem : memberList) {
							System.out.println(mem.toString());
							if(mem.memNumOfBooks == 0){
								System.out.println("No borrowed books");
							}
							//1 book borrowed
							else if(mem.memNumOfBooks == 1){
								//System.out.println(mem.memBook1.toString() + "\n+-+-+-+-+");
								System.out.println("BookID: " + mem.memBook1.bookId);
								System.out.println("Author: " + mem.memBook1.bookAuthor);
								System.out.println("Title: " + mem.memBook1.bookTitle);
								System.out.println("---------------------------------");
							}
							//2 books borrowed
							else{
								//System.out.println(mem.memBook1.toString());
								//System.out.println(mem.memBook2.toString() + "\n+-+-+-+-+");
								System.out.println("BookID: " + mem.memBook1.bookId);
								System.out.println("Author: " + mem.memBook1.bookAuthor);
								System.out.println("Title: " + mem.memBook1.bookTitle);
								System.out.println("---------------------------------");

								System.out.println("BookID: " + mem.memBook2.bookId);
								System.out.println("Author: " + mem.memBook2.bookAuthor);
								System.out.println("Title: " + mem.memBook2.bookTitle);
								System.out.println("---------------------------------");
							}
							System.out.println("---------------------------------");
						}

					}

					//view all books
					else if (input1.equals("6")) {
						System.out.println("---------------------------------");
						for (Book book : bookList) {
							//System.out.println(book.toString());
							System.out.println("BookID: " + book.bookId);
							System.out.println("Author: " + book.bookAuthor);
							System.out.println("Title: " + book.bookTitle);
							System.out.println("Total available copies: " + book.bookTotCopies);
							System.out.println("---------------------------------");
						}
					}

					else {
						System.out.println("---------------------------------");
						System.out.println("Invalid input, try again");
						System.out.println("---------------------------------");
					}
				}
			}

			//member entry case
			else if (input0.equals("2")) {
				//member codes here
				boolean memExists = false;
				Member curMem = null;
				System.out.println("---------------------------------");
				System.out.println("Enter a Member ID: ");
				scan.nextLine();
				String memContact = scan.nextLine();
				for (Member mem : memberList) {
					if (memContact.equalsIgnoreCase(mem.memId)) {
						System.out.println("\nWelcome Back " + mem.memName);
						memExists = true;
						curMem = mem;
						break;
					}
				}

				//current member is known by curMember
				if (memExists) {
					//start the member process
					while (true) {
						System.out.println("---------------------------------");
						System.out.println("List Available Books: 1\n" +
											"List My Books: 2" +
											"\nIssue book: 3" +
											"\nReturn book: 4" +
											"\nPay Fine: 5" +
											"\nBack: 6");
						String input2 = scan.nextLine();
						System.out.println("---------------------------------");

						//back ka case
						if (input2.equals("6")) {
							System.out.println("Going Back");
							System.out.println("---------------------------------");
							break;
						}

						//listing all available books
						else if (input2.equals("1")) {
							System.out.println("---------------------------------");
							for (Book book : bookList) {
								if (book.bookTotCopies > 0) {
									System.out.println(book.toString());
								}
							}
						}

						//list my books
						else if(input2.equals("2")){
							//no books borrowed
							if(curMem.memNumOfBooks == 0){
								System.out.println("No borrowed books");
							}

							//1 book borrowed
							else if(curMem.memNumOfBooks == 1){
								System.out.println("+-+-+-+-+\nTitle: " + curMem.memBook1.bookTitle +
													"\nAuthor: " + curMem.memBook1.bookAuthor +
													"\nID: " + curMem.memBook1.bookId);
							}

							//2 books borrowed
							else{
								System.out.println("+-+-+-+-+\nTitle: " + curMem.memBook1.bookTitle +
										"\nAuthor: " + curMem.memBook1.bookAuthor +
										"\nID: " + curMem.memBook1.bookId);
								System.out.println("+-+-+-+-+\nTitle: " + curMem.memBook2.bookTitle +
										"\nAuthor: " + curMem.memBook2.bookAuthor +
										"\nID: " + curMem.memBook2.bookId);
							}
						}

						//issue a book
						else if (input2.equals("3")) {
							System.out.println("---------------------------------");

							if (curMem.memNumOfBooks == 0) {
								System.out.println("Available Books: ");
								for (Book book : bookList) {
									System.out.println(book.toString());
								}
								System.out.println("---------------------------------");

								System.out.println("Enter BookID");
								scan.nextLine();
								String reqBookId = scan.nextLine();

								for (Book book : bookList) {
									if (book.bookId.equalsIgnoreCase(reqBookId)) {
										book.bookTotCopies--;
										curMem.memNumOfBooks++;

										curMem.memBook1.bookId = book.bookId;
										curMem.memBook1.bookAuthor = book.bookAuthor;
										curMem.memBook1.bookTitle = book.bookTitle;

										//setting the issue time
										curMem.memBook1.bookIssueTime = System.currentTimeMillis()/1000;

										break;
									}
								}
							}
							else if (curMem.memNumOfBooks == 2) {
								System.out.println("Sorry, a member can have a maximum of 2 books at a time");
							}

							//now checking for fine
							else {
								if (curMem.computeFine() != 0) {
									System.out.println("Fine pending of Rs. " + curMem.computeFine());
								}
								else {
									System.out.println("Available Books: ");
									for (Book book : bookList) {
										System.out.println(book.toString());
									}
									System.out.println("Enter BookID");
									scan.nextLine();
									String reqBookId = scan.nextLine();

									for (Book book : bookList) {
										if (book.bookId.equalsIgnoreCase(reqBookId)) {
											book.bookTotCopies--;
											curMem.memNumOfBooks++;


											curMem.memBook2.bookId = book.bookId;
											curMem.memBook2.bookAuthor = book.bookAuthor;
											curMem.memBook2.bookTitle = book.bookTitle;

											//setting the issue time
											curMem.memBook2.bookIssueTime = System.currentTimeMillis()/1000;

											break;
										}
									}
								}
							}
						}

						//Return Book
						else if (input2.equals("4")) {
							//2 book issued
							if (curMem.memNumOfBooks == 2) {
								System.out.println("---------------------------------");
								System.out.println(curMem.memBook1.toString());
								System.out.println("---------------------------------");
								System.out.println(curMem.memBook1.toString());
								System.out.println("---------------------------------");
								System.out.print("Enter BookID for the book to return: ");
								scan.nextLine();
								String reqBookID = scan.nextLine();

								//book1 to return
								if (curMem.memBook1.bookId.equalsIgnoreCase(reqBookID)) {
									for (Book book : bookList) {
										if (book.bookId.equalsIgnoreCase(reqBookID)) {
											book.bookTotCopies++;
											break;
										}
									}
									long retBookIssueTime = curMem.memBook1.bookIssueTime;

									curMem.memBook1.bookId = curMem.memBook2.bookId;
									curMem.memBook1.bookTitle = curMem.memBook2.bookTitle;
									curMem.memBook1.bookAuthor = curMem.memBook2.bookAuthor;
									curMem.memBook1.bookIssueTime = curMem.memBook2.bookIssueTime;
									curMem.memNumOfBooks--;
									curMem.memBook2.bookId = null;
									curMem.memBook2.bookTitle = null;
									curMem.memBook2.bookAuthor = null;
									curMem.memBook2.bookIssueTime = 0;

									curMem.memFine += curMem.computeFine(retBookIssueTime, 1);
									System.out.println("Returned book successfully\nFine due " + curMem.memFine);
								}

								//book2 to return
								else if (curMem.memBook2.bookId.equalsIgnoreCase(reqBookID)) {
									for (Book book : bookList) {
										if (book.bookId.equalsIgnoreCase(reqBookID)) {
											book.bookTotCopies++;
											break;
										}
									}

									long retBookIssueTime = curMem.memBook2.bookIssueTime;

									curMem.memBook2.bookId = null;
									curMem.memBook2.bookTitle = null;
									curMem.memBook2.bookAuthor = null;
									curMem.memBook2.bookIssueTime = 0;

									curMem.memFine += curMem.computeFine(retBookIssueTime, 1);
									System.out.println("Returned book successfully\nFine due " + curMem.memFine);
								}

								//invalid case
								else {
									System.out.println("You have not borrowed this book");
								}
							}

							//1 Book issued
							else if (curMem.memNumOfBooks == 1) {
								System.out.println("---------------------------------");
								System.out.println(curMem.memBook1.toString());
								System.out.println("---------------------------------");

								System.out.print("Enter BookID for the book to return: ");
								scan.nextLine();
								String reqBookID = scan.nextLine();

								//book1 to return
								if (curMem.memBook1.bookId.equalsIgnoreCase(reqBookID)) {
									//increasing total copies in bookList

									for (Book book : bookList) {
										if (book.bookId.equalsIgnoreCase(reqBookID)) {
											book.bookTotCopies++;
											break;
										}
									}
									long retBookIssueTime = curMem.memBook1.bookIssueTime;
									curMem.memBook1.bookId = null;
									curMem.memBook1.bookTitle = null;
									curMem.memBook1.bookAuthor = null;
									curMem.memBook1.bookIssueTime = 0;
									curMem.memNumOfBooks--;

									curMem.memFine += curMem.computeFine(retBookIssueTime, 1);
									System.out.println("Returned book successfully\nFine due " + curMem.memFine);
								}

							}

							//0 books
							else if (curMem.memNumOfBooks == 0) {
								System.out.println("You have not borrowed any book\nBorrow one to return it");
							}

							//invalid case
							else {
								System.out.println("You have not borrowed this book");
							}
						}

						//Pay Fine
						else if (input2.equals("5")) {
							System.out.println("---------------------------------");
							//long fine = curMem.computeFine();
							long totFine = curMem.computeFine();

							if(totFine>0){
								System.out.println("Amount payable: Rs" + totFine);
								System.out.println("Amount paying right now: ");
								int amt = scan.nextInt();
								curMem.memFine = totFine - amt;

								//updating
								if (curMem.memFine > 0) {
									System.out.println("Amount still payable: " + curMem.memFine);
								} else {
									long currTime = System.currentTimeMillis()/1000;
									curMem.memBook1.bookIssueTime = currTime;
									curMem.memBook2.bookIssueTime = currTime;
									System.out.println("Dues cleared");
								}
							}
							else {
								System.out.println("No Dues");
							}
						}

					}
				}

				else{
						System.out.println("Member doesn't exists or invalid contact input\nTo enter as member, enter '2' again!");
					}
				}

			else{
				System.out.println("Invalid Input\nTry again");
			}
		}



		//finishing statement
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxඞxxxxx ");
		System.out.println("Thank You for using our interface!");
		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

		scan.close();
	}
}