package Library;
// import java.util.*;
//import java.time.*;

public class Member {
	//attributes
	protected String memName;
	protected String memPhNo;
	protected int memAge;
	protected String memId;
	protected long memFine;
	protected int memNumOfBooks;
	
	Book memBook1 = new Book(null, 0);
	Book memBook2 = new Book(null, 0);

	//methods

	//constructor
	protected Member(String memName, String memPhNo, String memId, int memAge){
		this.memName = memName;
		this.memPhNo = memPhNo;
		this.memId = memId;
		this.memAge = memAge;
		this.memFine = 0;
		this.memNumOfBooks = 0;
	}

	//computing fine
	//long returnedTime = System.currentTimeMillis()/1000;
	public long computeFine(){
		//Instant currInst = Instant.now();
		//long currTime = currInst.getEpochSecond();
		long currTime = System.currentTimeMillis()/1000;
		//no books issued
		if(memNumOfBooks == 0){
			return 0;
		}

		//1 book issued
		else if(memNumOfBooks == 1){
			memFine = (currTime-memBook1.bookIssueTime - 10)*3;
			if(memFine <= 0){
				memFine = 0;
				return 0;
			}
			else{
				return memFine;
			}
		}

		//2 books issued
		else{				//book1 									book2
			long fine1 = (currTime-memBook1.bookIssueTime - 10)*3;
			long fine2 = (currTime-memBook2.bookIssueTime - 10)*3;

			if(fine1>0){
				memFine += fine1;
			}
			if(fine2>0){
				memFine += fine2;
			}

			if(memFine <= 0){
				memFine = 0;
				return 0;
			}
			else{
				return memFine;
			}
		}
	}

	//computing fine for the return case
	public long computeFine(long issueTime, int bookNum){
		//Instant currInst = Instant.now();
		//long currTime = currInst.getEpochSecond();
		long currTime = System.currentTimeMillis()/1000;
		//no books issued
		if(memNumOfBooks == 0){
			return memFine;
		}

		//1 book issued
		else if(memNumOfBooks == 1){
			memFine = (currTime - issueTime - 10)*3;
			if(memFine <= 0){
				memFine = 0;
				return 0;
			}
			else{
				return memFine;
			}
		}

		//2 books issued
		else{
			if(bookNum == 1){
				long fine1 = (currTime-issueTime - 10)*3;
				long fine2 = (currTime-memBook2.bookIssueTime - 10)*3;

				if(fine1>0){
					memFine += fine1;
				}
				if(fine2>0){
					memFine += fine2;
				}

				if(memFine <= 0){
					memFine = 0;
					return 0;
				}
				else{
					return memFine;
				}
			}
			else{
				long fine1 = (currTime - memBook1.bookIssueTime - 10)*3;
				long fine2 = (currTime - issueTime - 10)*3;

				if(fine1>0){
					memFine += fine1;
				}
				if(fine2>0){
					memFine += fine2;
				}

				if(memFine <= 0){
					memFine = 0;
					return 0;
				}
				else{
					return memFine;
				}
			}
		}
	}

	public String toString(){
		return "+-+-+-+-+\nName: " + memName +
						"\nPhone Number: " + memPhNo +
						"\nAge: " + memAge +
						"\nID: " + memId +
						"\nTotal Fine: " + computeFine() + "\n";
	}
}