/*
 * string bookId
 * string bookTitle
 * string bookAuthor
 * string TotCopies
 * string bookIssueTime
 * string bookReturnTime
 * string bookFine
 */

package Library;

public class Book {
	protected String bookId;
	protected String bookTitle;
	protected String bookAuthor;
	protected int bookTotCopies = 0;
	protected long bookIssueTime = 0;
	public Book(){
		//constructor with no arguments
	}

	//constructor when issuing a book by memberClass
	public Book(String bookId, long bookIssueTime){
		this.bookId = bookId;
		this.bookIssueTime = bookIssueTime;
		this.bookAuthor = null;
		this.bookTitle = null;
	}

	//constructor when adding a book by librarian
	public Book(String bookId, String bookTitle, String bookAuthor, int bookTotCopies){
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.bookTotCopies = bookTotCopies;
	}

	//toString()
	public String toString(){
		return "+-+-+-+-+\nTitle: " + bookTitle +
						"\nAuthor: " + bookAuthor +
						"\nID: " + bookId +
						"\nTotal Available Copies: " + bookTotCopies + "\n";
	}
}
