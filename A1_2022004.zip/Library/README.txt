Library Interface:

The project implements a library system.
One can use the interface as a librarian or a registered member
It has various functionalities:

As  Librarian:
	Register a member
		Allows a librarian to add a new member to the library
		It stores additional information such as Phone Number and Age and develops a memberID for the user
		Returns prompt if member already exists

	Remove a member
		Allows the librarian to remove a member completely from the records 
		using the unique memberID
	
	Add Book:
		Through input of Title, Author and total copies,
		a new bookID is generated of the format: <title>_<author> for the book title
		a librarian can add the book to library records
		Increase the total copies if book already exists
	
	Remove Book:
		Allows the librarian to remove a copy of the targeted book
		input is the BookID of the targeted book
	
	View Members
		Prints a list of all the member with their issued books and total pending fine onthe issued books
	
	View books
		Prints a list of books with their information,
		BookID, Title, Author and total available copies
	
As a Member:
	After logging into the interface with a UNIQUE valid memberID, you can perform the following tasks

	List available Books:
		Lists all the available books which can be issued by the member
	
	List member's Books:
		Displays a list of books borrowed by the member
	
	Issue Book
		Displays the list of books available for issuing
		Member can issue one by entering the BookID, provided that dues have been cleared
	
	Return Book
		Member can return the book if their dues have been cleared
		bookID of the book issued is required as input.
	
	Pay Fine:
		Displays the total fine accumulated for the member on the book/s borrowed by them
		Fine is calculated at Rs. 3 per day after 10 days of issue


Valid Inputs:
	Member
		Name: string sequence
		Phone Number: sequence of digits of any length
		Age: integer value

	Book:
		ID: string sequence
		Name: string sequence
		Title: string sequence
		Author: string sequence
		Total Copies: integer value

	Interface Navigation:
		Initial: integral values 1, 2 or 3
		Member: integral values 1, 2, 3, 4, 5 or
		Book: integral values 1, 2, 3, 4, 5, 6 or 7